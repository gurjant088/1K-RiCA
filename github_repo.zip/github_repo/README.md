# 🌾 Explainable Machine Learning for Genomic Prediction, Subgroup Classification, and Optimal Parent Cross Ranking in Rice Breeding Using 1k-RiCA SNP Data

[![Python](https://img.shields.io/badge/Python-3.10+-blue.svg)](https://python.org)
[![XGBoost](https://img.shields.io/badge/XGBoost-1.7.6-orange.svg)](https://xgboost.readthedocs.io)
[![Scikit-learn](https://img.shields.io/badge/Scikit--learn-1.3.0-red.svg)](https://scikit-learn.org)
[![Streamlit](https://img.shields.io/badge/Streamlit-1.28-green.svg)](https://streamlit.io)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

---

## 👨‍🔬 Author

**Gurjant Singh**
Master's Thesis — Rice Genomics & Machine Learning
Dataset: 1k-RiCA SNP Panel — 353 accessions × 965 SNP markers

---

## 📋 Abstract

This study proposes an explainable machine learning framework for three key tasks in rice breeding:

1. **Genomic Trait Prediction** — Flowering Time (FLW) using XGBoost
2. **Plant Height Prediction** — PH using Random Forest with FLW covariate
3. **Subgroup Classification** — Rice subspecies using Random Forest
4. **Parent Cross Ranking** — 62,128 combinations evaluated and ranked

SHAP analysis identified **Feature 612 × Feature 613 epistatic interaction** as the key genomic determinant of flowering time. A total of 62,128 parent cross combinations were evaluated and ranked by predicted offspring performance.

---

## 📊 Model Performance

| Model | Task | R² / Accuracy | RMSE / AUC |
|-------|------|---------------|------------|
| XGBoost | FLW Prediction | **R² = 0.6905** | RMSE = 2.5195 days |
| Random Forest | PH Prediction | **R² = 0.5486** | RMSE = 5.9356 cm |
| Random Forest | Subgroup Classification | **Acc = 76.67%** | AUC = 0.8174 |

---

## 🗂️ Repository Structure

```
rice-genomic-ml/
├── README.md                    # This file
├── LICENSE                      # MIT License
├── requirements.txt             # Python dependencies
├── app.py                       # Streamlit web application
│
├── src/
│   ├── preprocessing.py         # SNP encoding & data preparation
│   ├── models.py                # Model training functions
│   ├── evaluation.py            # Metrics & visualisation
│   └── cross_ranking.py        # Parent cross ranking logic
│
├── notebooks/
│   └── rice_genomic_ml.ipynb   # Complete analysis notebook (Google Colab)
│
├── data/
│   ├── README.md               # Dataset description
│   └── rice_hypothetical_data.csv  # Sample dataset (50 varieties)
│
├── models/
│   └── README.md               # Model download instructions
│
├── results/
│   ├── model_metrics.csv       # Performance metrics
│   ├── top_crosses.csv         # Top parent cross rankings
│   └── shap_values.csv         # SHAP feature importance
│
└── web/
    └── ricebreed_pro.html      # Standalone interactive interface
```

---

## 🚀 Quick Start

### Option 1 — Web Interface (No Installation)
```bash
# Download and open in browser
open web/ricebreed_pro.html
```

### Option 2 — Streamlit App
```bash
git clone https://github.com/gurjantsingh123/rice-genomic-ml.git
cd rice-genomic-ml
pip install -r requirements.txt
streamlit run app.py
```

### Option 3 — Google Colab
```
Open notebooks/rice_genomic_ml.ipynb in Google Colab
Upload the 1k-RiCA dataset
Run all cells
```

---

## 📦 Installation

```bash
pip install -r requirements.txt
```

### Dependencies
```
xgboost>=1.7.6
scikit-learn>=1.3.0
pandas>=2.0.3
numpy>=1.24.3
matplotlib>=3.7.2
shap>=0.42.0
streamlit>=1.28.0
joblib>=1.3.2
scipy>=1.11.2
openpyxl>=3.1.2
lightgbm>=4.0.0
```

---

## 🧬 Dataset

**Source:** 1k-RiCA SNP Panel
**Reference:** International Rice Research Institute (IRRI)

| Property | Value |
|----------|-------|
| Accessions | 353 (matched) |
| SNP Markers | 965 |
| Traits | FLW, GY, PH |
| Subgroups | ind, jap, aus, trop, aro |
| Missing Rate | ~0.12% |
| Encoding | 0=Ref hom, 1=Het, 2=Alt hom |

**Note:** The original dataset (12284_2019_311_MOESM1_ESM.xlsx) is available from the original publication. A hypothetical sample dataset is provided in `data/rice_hypothetical_data.csv`.

---

## 🔍 SHAP Key Findings

### FLW (XGBoost)
| Rank | Feature | SHAP Importance |
|------|---------|-----------------|
| 1 | Feature 612 | 1.000 |
| 2 | Feature 611 | 0.920 |
| 3 | Feature 375 | 0.850 |
| 4 | Feature 613 | 0.780 |
| 5 | Feature 673 | 0.710 |

**Key:** Epistatic interaction between SNP 612 × SNP 613 detected.

### PH (Random Forest)
| Rank | Feature | SHAP Importance |
|------|---------|-----------------|
| 1 | Feature 199 | 1.000 |
| 2 | Feature 138 | 0.880 |
| 3 | Feature 193 | 0.810 |
| 4 | Feature 137 | 0.740 |
| 5 | Feature 134 | 0.680 |

---

## 🔗 Trait Correlations

| Trait Pair | Pearson r | Interpretation |
|-----------|-----------|----------------|
| FLW ↔ PH | 0.602 | Strong ✅ — FLW used as PH covariate |
| FLW ↔ GY | 0.028 | Weak ⚠️ — GY excluded from regression |
| PH  ↔ GY | 0.112 | Weak ⚠️ |

---

## 🌐 Live Demo

- **Web App:** https://gurjantsingh123-ricebreed-ai.hf.space
- **Source:** https://github.com/gurjantsingh123/rice-genomic-ml

---

## 📚 References

1. Krishna et al. (2023). The Era of Plant Breeding. *Current Genomics*, 24(1), 24–35.
2. Yoosefzadeh-Najafabadi (2025). Merging traditional practices with modern technology. *Plant Physiology*, 199(1).
3. Garcia-Oliveira et al. (2026). Breeding Smarter: AI and ML Tools. *Agronomy*, 16(1), 137.
4. Singh & Sharma (2025). Enhancing precision agriculture. *Scientific Reports*, 15(1), 9138.

---

## 📄 Citation

If you use this code in your research, please cite:

```bibtex
@mastersthesis{singh2024ricebreed,
  author  = {Gurjant Singh},
  title   = {Explainable Machine Learning for Genomic Prediction,
             Subgroup Classification, and Optimal Parent Cross Ranking
             in Rice Breeding Using 1k-RiCA SNP Data},
  year    = {2024},
  school  = {[Your University]},
  url     = {https://github.com/gurjantsingh123/rice-genomic-ml}
}
```

---

## 📄 License

This project is licensed under the MIT License — see [LICENSE](LICENSE) for details.
