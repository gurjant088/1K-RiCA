"""
cross_ranking.py
----------------
Parent cross ranking logic for rice breeding.
Author: Gurjant Singh — Master's Thesis
"""

import numpy as np
import pandas as pd
import itertools


def rank_all_crosses(varieties, pred_flw, pred_ph, avg_gy=None):
    """
    Evaluate and rank all pairwise parent cross combinations.

    Parameters
    ----------
    varieties : array-like  variety names
    pred_flw  : np.ndarray  XGBoost predicted FLW per variety
    pred_ph   : np.ndarray  RF predicted PH per variety
    avg_gy    : np.ndarray  grain yield per variety (optional)

    Returns
    -------
    pd.DataFrame  sorted by Score descending, with columns:
        Rank, Parent_1, Parent_2, Pred_FLW, Pred_PH, Avg_GY, Score
    """
    n      = len(varieties)
    if avg_gy is None:
        avg_gy = np.ones(n) * 4.0

    maxFLW = pred_flw.max(); minFLW = pred_flw.min()
    maxPH  = pred_ph.max()

    rows = []
    for i, j in itertools.combinations(range(n), 2):
        af = (pred_flw[i] + pred_flw[j]) / 2
        ap = (pred_ph[i]  + pred_ph[j])  / 2
        ag = (avg_gy[i]   + avg_gy[j])   / 2
        score = (
            (ap / maxPH) -
            (af / maxFLW) +
            (1 - (af - minFLW) / (maxFLW - minFLW + 1e-9))
        )
        rows.append({
            'Parent_1': varieties[i],
            'Parent_2': varieties[j],
            'Pred_FLW': round(float(af), 3),
            'Pred_PH':  round(float(ap), 3),
            'Avg_GY':   round(float(ag), 3),
            'Score':    round(float(score), 4)
        })

    result = pd.DataFrame(rows).sort_values(
        'Score', ascending=False
    ).reset_index(drop=True)
    result.index += 1
    result.index.name = 'Rank'
    return result


def top_k_accuracy_regression(y_true, y_pred, k):
    """
    Top-K rank overlap accuracy for regression.
    Fraction of top-K predicted that appear in top-K actual.
    """
    actual_top = set(np.argsort(y_true)[::-1][:k])
    pred_top   = set(np.argsort(y_pred)[::-1][:k])
    return len(actual_top & pred_top) / k


def summarize_top_crosses(cross_df, top_k=10):
    """Print a formatted summary of the top-K crosses."""
    print(f"\n{'='*60}")
    print(f"  TOP {top_k} PARENT CROSSES")
    print(f"{'='*60}")
    for i, row in cross_df.head(top_k).iterrows():
        print(f"  {i:>3}. {row['Parent_1']:<20} × {row['Parent_2']:<20} "
              f"| FLW:{row['Pred_FLW']:>6} | PH:{row['Pred_PH']:>6} "
              f"| Score:{row['Score']:>7}")
    print(f"\n  Total evaluated: {len(cross_df):,}")
