"""
models.py
---------
Model training, saving, and loading for rice genomic prediction.
Author: Gurjant Singh — Master's Thesis
"""

import numpy as np
import joblib
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.linear_model import RidgeCV
from sklearn.metrics import r2_score, mean_squared_error, accuracy_score
from sklearn.model_selection import train_test_split, cross_val_score, KFold
from xgboost import XGBRegressor


def train_xgboost_flw(X, y, test_size=0.2, random_state=42):
    """
    Train XGBoost for Flowering Time (FLW) prediction.

    Returns model, metrics_dict
    """
    X_tr, X_te, y_tr, y_te = train_test_split(
        X, y, test_size=test_size, random_state=random_state
    )
    model = XGBRegressor(
        n_estimators    = 500,
        max_depth       = 4,
        learning_rate   = 0.01,
        reg_alpha       = 0.01,
        reg_lambda      = 1.0,
        subsample       = 0.9,
        colsample_bytree= 0.5,
        random_state    = random_state,
        verbosity       = 0,
    )
    model.fit(X_tr, y_tr)
    y_pred = model.predict(X_te)
    r2     = r2_score(y_te, y_pred)
    rmse   = np.sqrt(mean_squared_error(y_te, y_pred))
    cv     = cross_val_score(model, X, y, cv=5, scoring='r2')

    print(f"XGBoost FLW — R²={r2:.4f}  RMSE={rmse:.4f}  CV={cv.mean():.4f}±{cv.std():.4f}")
    return model, {
        'r2': r2, 'rmse': rmse,
        'cv_mean': cv.mean(), 'cv_std': cv.std(),
        'model': 'XGBoost', 'trait': 'FLW'
    }


def train_rf_ph(X, y, test_size=0.2, random_state=42):
    """
    Train Random Forest for Plant Height (PH) prediction.

    Returns model, metrics_dict
    """
    X_tr, X_te, y_tr, y_te = train_test_split(
        X, y, test_size=test_size, random_state=random_state
    )
    model = RandomForestRegressor(
        n_estimators   = 600,
        max_depth      = None,
        min_samples_leaf= 1,
        max_features   = 0.4,
        bootstrap      = True,
        random_state   = random_state,
        n_jobs         = -1,
    )
    model.fit(X_tr, y_tr)
    y_pred = model.predict(X_te)
    r2     = r2_score(y_te, y_pred)
    rmse   = np.sqrt(mean_squared_error(y_te, y_pred))
    cv     = cross_val_score(model, X, y, cv=5, scoring='r2')

    print(f"RandomForest PH — R²={r2:.4f}  RMSE={rmse:.4f}  CV={cv.mean():.4f}±{cv.std():.4f}")
    return model, {
        'r2': r2, 'rmse': rmse,
        'cv_mean': cv.mean(), 'cv_std': cv.std(),
        'model': 'RandomForest', 'trait': 'PH'
    }


def train_rf_classifier(X, y, le_cls, test_size=0.2, random_state=42):
    """
    Train Random Forest for rice subgroup classification.

    Returns model, metrics_dict
    """
    X_tr, X_te, y_tr, y_te = train_test_split(
        X, y, test_size=test_size,
        random_state=random_state, stratify=y
    )
    model = RandomForestClassifier(
        n_estimators = 300,
        max_depth    = 10,
        random_state = random_state,
        n_jobs       = -1,
    )
    model.fit(X_tr, y_tr)
    acc = accuracy_score(y_te, model.predict(X_te))
    cv  = cross_val_score(model, X, y, cv=5, scoring='accuracy')

    print(f"RandomForest Class — Acc={acc:.4f}  CV={cv.mean():.4f}±{cv.std():.4f}")
    return model, {
        'accuracy': acc,
        'cv_mean': cv.mean(), 'cv_std': cv.std(),
        'model': 'RandomForest', 'task': 'Classification'
    }


def save_all_models(models_dict, save_dir='models'):
    """Save all model objects to disk."""
    import os
    os.makedirs(save_dir, exist_ok=True)
    for name, obj in models_dict.items():
        path = f"{save_dir}/{name}.pkl"
        joblib.dump(obj, path)
        print(f"✅ Saved: {path}")


def load_all_models(save_dir='models'):
    """Load all model .pkl files from directory."""
    import os
    loaded = {}
    for fname in os.listdir(save_dir):
        if fname.endswith('.pkl'):
            key = fname.replace('.pkl', '')
            loaded[key] = joblib.load(f"{save_dir}/{fname}")
    print(f"✅ Loaded {len(loaded)} models from {save_dir}/")
    return loaded
