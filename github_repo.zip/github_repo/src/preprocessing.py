"""
preprocessing.py
----------------
SNP encoding and data preparation for 1k-RiCA genomic data.
Author: Gurjant Singh — Master's Thesis
"""

import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.feature_selection import SelectKBest, f_regression

META_COLS = [
    'alleles', 'chrom', 'pos', 'strand', 'assembly#',
    'center', 'protLSID', 'assayLSID', 'panelLSID', 'QCcode'
]


def normalize_id(val):
    """Normalize sample IDs to consistent string format."""
    try:
        return str(int(float(str(val).strip())))
    except Exception:
        return str(val).strip()


def encode_snp(snp_df):
    """
    Encode SNP genotype matrix from nucleotide to numeric (0/1/2).

    Parameters
    ----------
    snp_df : pd.DataFrame
        Raw SNP dataframe with meta columns and genotype data.

    Returns
    -------
    X   : np.ndarray  shape (n_samples, n_snps)
    ids : np.ndarray  sample IDs as strings
    """
    clean = snp_df.drop(
        columns=[c for c in META_COLS if c in snp_df.columns]
    )
    T = clean.T.reset_index()
    T.columns = ['Variety'] + list(T.columns[1:])

    le   = LabelEncoder()
    cols = T.columns[1:]
    X    = T[cols].apply(
        lambda col: le.fit_transform(col.astype(str))
    ).values.astype(float)
    ids  = T['Variety'].astype(str).str.strip().values
    return X, ids


def match_samples(snp_ids, pheno_ids):
    """
    Match sample IDs between SNP and phenotype datasets.

    Returns
    -------
    common    : np.ndarray  shared IDs
    snp_idx   : list[int]   indices into SNP array
    pheno_idx : list[int]   indices into phenotype array
    """
    snp_norm   = np.array([normalize_id(i) for i in snp_ids])
    pheno_norm = np.array([normalize_id(i) for i in pheno_ids])
    common     = np.intersect1d(snp_norm, pheno_norm)

    snp_idx   = [np.where(snp_norm   == i)[0][0] for i in common]
    pheno_idx = [np.where(pheno_norm == i)[0][0] for i in common]
    return common, snp_idx, pheno_idx


def prepare_flw_data(X_snp, y_flw):
    """
    Scale SNP features for FLW prediction.

    Returns X_scaled, scaler
    """
    scaler   = StandardScaler()
    X_scaled = scaler.fit_transform(X_snp)
    return X_scaled, scaler


def prepare_ph_data(X_snp, y_flw, y_ph, scaler, k=200):
    """
    Scale SNP features, add FLW covariate, apply SelectKBest for PH.

    Returns X_selected, selector
    """
    X_scaled   = scaler.transform(X_snp)
    X_with_flw = np.hstack([X_scaled, y_flw.reshape(-1, 1)])
    selector   = SelectKBest(f_regression, k=k)
    X_selected = selector.fit_transform(X_with_flw, y_ph)
    return X_selected, selector


def generate_all_crosses(pheno_df, pred_flw, pred_ph,
                          variety_col='Variety', gy_col='GY'):
    """
    Generate all pairwise parent cross combinations and score them.

    Score = (avg_pred_PH / max_PH) - (avg_pred_FLW / max_FLW)
            + (1 - (avg_pred_FLW - min_FLW) / (max_FLW - min_FLW))

    Returns pd.DataFrame sorted by Score descending.
    """
    import itertools

    varieties = pheno_df[variety_col].values
    gys       = pheno_df[gy_col].values if gy_col in pheno_df.columns \
                else np.ones(len(pheno_df)) * 4.0
    n         = len(pheno_df)

    maxFLW = pred_flw.max(); minFLW = pred_flw.min()
    maxPH  = pred_ph.max()

    rows = []
    for i, j in itertools.combinations(range(n), 2):
        af = (pred_flw[i] + pred_flw[j]) / 2
        ap = (pred_ph[i]  + pred_ph[j])  / 2
        ag = (gys[i]      + gys[j])      / 2
        score = (ap / maxPH) - (af / maxFLW) + \
                (1 - (af - minFLW) / (maxFLW - minFLW + 1e-9))
        rows.append({
            'Parent_1': varieties[i],
            'Parent_2': varieties[j],
            'Pred_FLW': round(float(af), 3),
            'Pred_PH':  round(float(ap), 3),
            'Avg_GY':   round(float(ag), 3),
            'Score':    round(float(score), 4)
        })

    return pd.DataFrame(rows).sort_values(
        'Score', ascending=False
    ).reset_index(drop=True)
