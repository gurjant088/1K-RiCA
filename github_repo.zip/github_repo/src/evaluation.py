"""
evaluation.py
-------------
Model evaluation metrics and visualisation.
Author: Gurjant Singh — Master's Thesis
"""

import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import (
    r2_score, mean_squared_error, mean_absolute_error,
    accuracy_score, classification_report,
    roc_auc_score, confusion_matrix
)
from sklearn.preprocessing import label_binarize


def regression_report(y_true, y_pred, model_name='Model', trait='Trait'):
    """Print and return regression metrics."""
    r2   = r2_score(y_true, y_pred)
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    mae  = mean_absolute_error(y_true, y_pred)

    print(f"\n{'='*50}")
    print(f"  {model_name} — {trait}")
    print(f"{'='*50}")
    print(f"  R² Score : {r2:.4f}")
    print(f"  RMSE     : {rmse:.4f}")
    print(f"  MAE      : {mae:.4f}")
    return {'r2': r2, 'rmse': rmse, 'mae': mae}


def plot_actual_vs_predicted(y_true, y_pred, title='', color='steelblue', ax=None):
    """Scatter plot of actual vs predicted values."""
    if ax is None:
        fig, ax = plt.subplots(figsize=(6, 5))
    ax.scatter(y_true, y_pred, alpha=0.6, color=color, edgecolors='k', s=55)
    mn = min(y_true.min(), y_pred.min()) - 1
    mx = max(y_true.max(), y_pred.max()) + 1
    ax.plot([mn, mx], [mn, mx], 'r--', lw=1.8, label='Perfect fit')
    ax.set_title(f'{title}\nR²={r2_score(y_true,y_pred):.4f}', fontsize=12)
    ax.set_xlabel('Actual');  ax.set_ylabel('Predicted')
    ax.legend(); ax.grid(True, alpha=0.25)
    return ax


def plot_shap_bars(shap_names, shap_values, title='SHAP Feature Importance',
                   color='steelblue', ax=None):
    """Horizontal bar chart of SHAP importance."""
    if ax is None:
        fig, ax = plt.subplots(figsize=(8, 5))
    idx  = np.argsort(shap_values)
    ax.barh([shap_names[i] for i in idx],
            [shap_values[i] for i in idx],
            color=color, edgecolor='white', alpha=0.85)
    ax.set_title(title, fontsize=12)
    ax.set_xlabel('Relative SHAP Importance')
    ax.grid(True, alpha=0.2, axis='x')
    return ax


def plot_confusion_matrix(y_true, y_pred, classes, ax=None):
    """Plot confusion matrix heatmap."""
    if ax is None:
        fig, ax = plt.subplots(figsize=(6, 5))
    cm = confusion_matrix(y_true, y_pred)
    im = ax.imshow(cm, cmap='Blues')
    ax.set_xticks(range(len(classes))); ax.set_xticklabels(classes, rotation=45)
    ax.set_yticks(range(len(classes))); ax.set_yticklabels(classes)
    for i in range(len(classes)):
        for j in range(len(classes)):
            ax.text(j, i, cm[i,j], ha='center', va='center', fontweight='bold')
    ax.set_title('Confusion Matrix')
    ax.set_ylabel('True label'); ax.set_xlabel('Predicted label')
    plt.colorbar(im, ax=ax)
    return ax
