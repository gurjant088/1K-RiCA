# Data Directory

## rice_hypothetical_data.csv

Sample dataset with 50 hypothetical rice varieties for testing.

| Column | Description | Range |
|--------|-------------|-------|
| Variety | Variety name | text |
| FLW | Flowering time (days) | 70–120 |
| GY | Grain yield (t/ha) | 2.5–7.0 |
| PH | Plant height (cm) | 75–135 |

## Real Dataset

The original 1k-RiCA dataset (`12284_2019_311_MOESM1_ESM.xlsx`) is not
included due to file size. It is available from the original publication:

**Sheets used:**
- `Supplementary File 7` — SNP markers (numeric sample IDs) → regression
- `Supplementary File 4` — SNP markers (variety name IDs) → classification
- `Supplementary File 1` — Accession subgroup labels
- `Genomic selection-adjusted mean` — Phenotypic traits (FLW, GY, PH)

## results/

- `model_metrics.csv` — R², RMSE for all models
- `top_crosses.csv` — Top 100 parent cross rankings
- `shap_values.csv` — SHAP feature importance for FLW and PH models
