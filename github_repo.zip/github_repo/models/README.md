# Models Directory

Trained model `.pkl` files are not included due to file size.

## Generate Models

Run `notebooks/rice_genomic_ml.ipynb` in Google Colab with the
1k-RiCA dataset, then download `models_bundle.zip` and extract here.

## Expected Files

| File | Model | Task | Score |
|------|-------|------|-------|
| `xgb_flw.pkl` | XGBoost | FLW Prediction | R²=0.6905 |
| `rf_ph.pkl` | Random Forest | PH Prediction | R²=0.5486 |
| `rf_cls.pkl` | Random Forest | Classification | Acc=76.67% |
| `scaler_reg.pkl` | StandardScaler | Feature scaling | — |
| `selector_ph.pkl` | SelectKBest | Top 200 SNPs for PH | — |
| `metrics.pkl` | dict | Performance metrics | — |

## Hyperparameters

### XGBoost — FLW
```
n_estimators=500, max_depth=4, learning_rate=0.01
reg_alpha=0.01, subsample=0.9, colsample_bytree=0.5
```

### Random Forest — PH
```
n_estimators=600, max_depth=None, min_samples_leaf=1
max_features=0.4, bootstrap=True
Feature selection: SelectKBest(k=200) + FLW covariate
```

### Random Forest — Classification
```
n_estimators=300, max_depth=10
Subgroups: ind, jap, aus, trop, aro
```
